class LickDetectorError(Exception):
    pass