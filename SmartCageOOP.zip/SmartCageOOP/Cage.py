class Cage:

    def __init__(self):




