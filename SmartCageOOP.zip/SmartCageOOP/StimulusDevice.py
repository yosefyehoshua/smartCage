import RPi.GPIO as GPIO

class StimulusDevice:




